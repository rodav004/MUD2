/**
 * Provides a Cocoa-inspired system for broadcasting messages to various objects.
 */
package net.michaelsavich.notification;