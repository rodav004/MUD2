package mud;

public class Door {
	Room room;

	public Door(Room room) {
		this.room = room;
	}
	
}