package mud;
import java.util.Arrays;
import java.util.List;
public class Parse {
/**
 * 
 * @param playerOne the character doing the action
 * @param input the action to be done
 * @return a String saying the result of the action
 */
	public static String parse(Character playerOne, String input) {
		String[] arr = input.split(" ");
		String action = arr[0];
		String direction = arr[1];
		String r;
		if (action.equals("move")) {
			r = playerOne.move(direction);
		}
		else if (action.equals("get")) {
			r = playerOne.addItem(direction);
		}
		else if (action.equals("drop")) {
			r = playerOne.removeItem(direction);
		}
		else {
			r = "Oops! I don't know what you're trying to say!";
		}
		return r;
	}

}
