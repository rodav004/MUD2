package mud;

public class Item extends GameObject {

	public Item(String name, String description) {
	this.name = name;
	this.description = description;
	}
	
}